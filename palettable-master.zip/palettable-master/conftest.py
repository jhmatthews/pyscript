try:
    import matplotlib
except ImportError:
    pass
else:
    matplotlib.use('Agg')
